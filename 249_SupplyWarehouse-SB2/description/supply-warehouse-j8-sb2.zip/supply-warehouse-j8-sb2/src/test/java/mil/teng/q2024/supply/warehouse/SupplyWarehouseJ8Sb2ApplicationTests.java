package mil.teng.q2024.supply.warehouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplyWarehouseJ8Sb2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
