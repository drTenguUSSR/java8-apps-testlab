package mil.teng.q2024.supply.warehouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplyWarehouseJ8Sb2Application {

	public static void main(String[] args) {
		SpringApplication.run(SupplyWarehouseJ8Sb2Application.class, args);
	}

}
